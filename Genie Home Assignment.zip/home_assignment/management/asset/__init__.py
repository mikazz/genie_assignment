from .resolver import get_assets
